# ThinkTest — React (Vite) Ready Project

This is a client-side React port of the single-file HTML + inline JS ThinkTest app.

## Quick start

```bash
npm install
npm run dev
```

Then open http://localhost:5173.
